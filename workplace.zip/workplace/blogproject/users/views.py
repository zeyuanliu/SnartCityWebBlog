from django.shortcuts import render, redirect
from django.contrib.auth import logout
from .forms import RegisterForm
from django.http import HttpResponseRedirect
# Create your views here.


def register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/users/login/')
    else:
        form = RegisterForm()
    return render(request, 'blog/register.html', context={'form': form})

def logout_view(request):
    logout(request)
    return HttpResponseRedirect('/users/login/')