# Create your views here.
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from django.shortcuts import render, get_object_or_404, redirect
from .models import Post, Category
import markdown
from comments.forms import CommentForm


@login_required
def index(request):
    post_list = Post.objects.all()
    return render(request, 'blog/index.html', context={'post_list': post_list})


@login_required
def detail(request, pk):
    post = get_object_or_404(Post, pk=pk)

    # view increasing
    post.increase_views()
    post.body = markdown.markdown(
        post.body,
        extentions=[
            'markdown.extensions.extra',
            'markdown.extensions.codehilite',
            'markdown.extensions.toc',
        ]
    )
    form = CommentForm()
    comment_list = post.comment_set.all()
    content = {
        'post': post,
        'form': form,
        'comment_list': comment_list
    }
    return render(request, 'blog/detail.html', context={'content': content})




def archives(request, year, month):
    post_list = Post.objects.filter(created_time__year=year, created_time__month=month)
    return render(request, 'blog/index.html', content={'post_list': post_list})


def category(request, pk):
    cate = get_object_or_404(Category, pk=pk)
    post_list = Post.objects.filter(category=cate)
    return render(request, 'blog/index.html', context={'post_list': post_list})


def post_article(request):
    if request.method == 'GET':
        return render(request, 'blog/post_article.html', context={})
    else:
        category, created = Category.objects.get_or_create(name=request.POST['category'])
        post = Post.objects.create(
            title = request.POST['title'],
            body=request.POST['body'],
            excerpt_time=request.POST['excerpt_time'],
            category=category,
            author=request.user,
        )
        return redirect(post)


def myarticle(request):
    post_list = Post.objects.filter(author=request.user)
    return render(request, 'blog/index.html', context={'post_list': post_list})


def about(request):
    return render(request, 'blog/about.html')